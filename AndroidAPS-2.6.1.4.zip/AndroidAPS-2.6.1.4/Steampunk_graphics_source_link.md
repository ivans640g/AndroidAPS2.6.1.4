Follow this link to get the source PSD file for the Steampunk graphics. The file could not be included in the repository as it exceeds Github's 25 mb limit.

Note, the source image size is 1600x1600. The image size should be reduced to 400x400 prior to export of final PNG.

https://drive.google.com/drive/folders/1MrdgnQz3wOniDvRSMhAsqHBYb2WmE5i0

Graphics created by (Github): andrew-warrington