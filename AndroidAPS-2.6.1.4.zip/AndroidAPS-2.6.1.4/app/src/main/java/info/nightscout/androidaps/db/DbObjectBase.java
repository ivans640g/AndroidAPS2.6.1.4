package info.nightscout.androidaps.db;

public interface DbObjectBase {

    long getDate();

    long getPumpId();

}
