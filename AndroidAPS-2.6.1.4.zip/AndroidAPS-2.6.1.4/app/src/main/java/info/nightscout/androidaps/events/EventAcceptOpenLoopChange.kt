package info.nightscout.androidaps.events

class EventAcceptOpenLoopChange : Event()
