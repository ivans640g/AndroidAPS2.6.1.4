package info.nightscout.androidaps.events

class EventAppExit : Event()