package info.nightscout.androidaps.events

class EventAppInitialized : Event()