package info.nightscout.androidaps.events

class EventBolusRequested(var amount: Double) : Event()