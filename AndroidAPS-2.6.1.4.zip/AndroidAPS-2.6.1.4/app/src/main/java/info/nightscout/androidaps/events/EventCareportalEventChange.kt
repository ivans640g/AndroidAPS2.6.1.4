package info.nightscout.androidaps.events

class EventCareportalEventChange : Event()
