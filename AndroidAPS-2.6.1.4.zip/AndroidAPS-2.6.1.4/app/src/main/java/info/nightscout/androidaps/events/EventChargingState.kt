package info.nightscout.androidaps.events

class EventChargingState(val isCharging: Boolean) : Event()
