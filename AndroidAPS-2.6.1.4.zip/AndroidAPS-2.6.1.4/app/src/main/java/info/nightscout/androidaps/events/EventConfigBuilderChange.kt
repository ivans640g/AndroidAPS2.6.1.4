package info.nightscout.androidaps.events

class EventConfigBuilderChange : Event()
