package info.nightscout.androidaps.events

class EventCustomActionsChanged : Event()
