package info.nightscout.androidaps.events

class EventCustomCalculationFinished : Event()