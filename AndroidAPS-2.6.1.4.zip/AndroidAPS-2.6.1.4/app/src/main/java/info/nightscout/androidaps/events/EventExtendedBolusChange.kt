package info.nightscout.androidaps.events

class EventExtendedBolusChange : EventLoop()
