package info.nightscout.androidaps.events

class EventFoodDatabaseChanged : Event()