package info.nightscout.androidaps.events

class EventInitializationChanged : Event()
