package info.nightscout.androidaps.events

import android.location.Location

class EventLocationChange(var location: Location) : Event()
