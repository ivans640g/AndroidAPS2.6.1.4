package info.nightscout.androidaps.events

/** Supeclass for all events concerned with input or output into or from the LoopPlugin.  */
abstract class EventLoop : Event()
