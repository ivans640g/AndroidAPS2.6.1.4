package info.nightscout.androidaps.events

class EventNewBasalProfile : Event()