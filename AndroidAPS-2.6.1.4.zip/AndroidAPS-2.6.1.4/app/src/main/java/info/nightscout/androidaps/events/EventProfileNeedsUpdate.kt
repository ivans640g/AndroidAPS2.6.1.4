package info.nightscout.androidaps.events

class EventProfileNeedsUpdate : Event()