package info.nightscout.androidaps.events

class EventProfileStoreChanged : Event()
