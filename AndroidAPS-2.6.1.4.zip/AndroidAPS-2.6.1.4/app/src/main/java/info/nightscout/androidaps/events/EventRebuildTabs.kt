package info.nightscout.androidaps.events

class EventRebuildTabs @JvmOverloads constructor(var recreate: Boolean = false) : Event()
