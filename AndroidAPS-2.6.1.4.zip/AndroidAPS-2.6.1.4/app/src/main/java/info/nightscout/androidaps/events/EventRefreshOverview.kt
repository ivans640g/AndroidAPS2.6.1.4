package info.nightscout.androidaps.events

class EventRefreshOverview(var from: String) : Event()
