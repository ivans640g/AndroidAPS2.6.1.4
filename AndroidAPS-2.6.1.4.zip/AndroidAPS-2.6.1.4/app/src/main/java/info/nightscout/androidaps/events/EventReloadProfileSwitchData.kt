package info.nightscout.androidaps.events

class EventReloadProfileSwitchData : Event()
