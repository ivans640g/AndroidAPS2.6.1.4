package info.nightscout.androidaps.events

class EventReloadTempBasalData : Event()
