package info.nightscout.androidaps.events

class EventReloadTreatmentData(var next: Event) : Event()
