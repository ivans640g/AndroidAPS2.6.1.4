package info.nightscout.androidaps.events

class EventTempBasalChange : EventLoop()
