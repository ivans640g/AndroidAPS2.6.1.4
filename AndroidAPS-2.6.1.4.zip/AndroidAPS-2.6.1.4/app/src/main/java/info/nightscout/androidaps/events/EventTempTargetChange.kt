package info.nightscout.androidaps.events

class EventTempTargetChange : Event()
