package info.nightscout.androidaps.events

/** Base class for events to update the UI, mostly a specific tab.  */
abstract class EventUpdateGui : Event()
