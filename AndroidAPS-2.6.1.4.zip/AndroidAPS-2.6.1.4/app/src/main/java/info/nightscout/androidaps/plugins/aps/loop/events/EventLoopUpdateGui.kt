package info.nightscout.androidaps.plugins.aps.loop.events

import info.nightscout.androidaps.events.EventUpdateGui

/**
 * Created by mike on 05.08.2016.
 */
class EventLoopUpdateGui : EventUpdateGui()
