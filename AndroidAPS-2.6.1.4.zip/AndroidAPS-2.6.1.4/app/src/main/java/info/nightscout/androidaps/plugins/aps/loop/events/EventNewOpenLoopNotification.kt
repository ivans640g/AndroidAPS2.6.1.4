package info.nightscout.androidaps.plugins.aps.loop.events

import info.nightscout.androidaps.events.Event

class EventNewOpenLoopNotification : Event()