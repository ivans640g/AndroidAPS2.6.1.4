package info.nightscout.androidaps.plugins.aps.openAPSMA.events

import info.nightscout.androidaps.events.EventUpdateGui

class EventOpenAPSUpdateGui : EventUpdateGui()
