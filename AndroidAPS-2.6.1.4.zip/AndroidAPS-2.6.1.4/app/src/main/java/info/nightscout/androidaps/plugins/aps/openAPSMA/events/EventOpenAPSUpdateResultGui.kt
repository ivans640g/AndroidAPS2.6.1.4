package info.nightscout.androidaps.plugins.aps.openAPSMA.events

import info.nightscout.androidaps.events.EventUpdateGui

class EventOpenAPSUpdateResultGui(val text: String) : EventUpdateGui()
