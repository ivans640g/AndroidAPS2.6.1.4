package info.nightscout.androidaps.plugins.configBuilder

import info.nightscout.androidaps.events.EventUpdateGui

class EventConfigBuilderUpdateGui : EventUpdateGui() {
}