package info.nightscout.androidaps.plugins.constraints.objectives.events

import info.nightscout.androidaps.events.EventUpdateGui

class EventObjectivesUpdateGui : EventUpdateGui()