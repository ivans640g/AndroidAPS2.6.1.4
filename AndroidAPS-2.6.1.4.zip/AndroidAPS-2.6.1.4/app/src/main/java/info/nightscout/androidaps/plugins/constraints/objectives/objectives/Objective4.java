package info.nightscout.androidaps.plugins.constraints.objectives.objectives;

import info.nightscout.androidaps.R;

public class Objective4 extends Objective {

    public Objective4() {
        super("maxbasal", R.string.objectives_maxbasal_objective, R.string.objectives_maxbasal_gate);
    }
}
