package info.nightscout.androidaps.plugins.general.actions.defs

interface CustomActionType {
    val key: String?
}