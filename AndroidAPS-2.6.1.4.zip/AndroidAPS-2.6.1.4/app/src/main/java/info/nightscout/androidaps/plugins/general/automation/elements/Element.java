package info.nightscout.androidaps.plugins.general.automation.elements;

import android.widget.LinearLayout;

public abstract class Element {
    public abstract void addToLayout(LinearLayout root);
}
