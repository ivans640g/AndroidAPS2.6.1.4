package info.nightscout.androidaps.plugins.general.automation.events

import info.nightscout.androidaps.events.Event
import info.nightscout.androidaps.plugins.general.automation.actions.Action

class EventAutomationAddAction(val action: Action) : Event()
