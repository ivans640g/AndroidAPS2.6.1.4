package info.nightscout.androidaps.plugins.general.automation.events

import info.nightscout.androidaps.events.Event

class EventAutomationDataChanged : Event()
