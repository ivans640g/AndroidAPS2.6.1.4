package info.nightscout.androidaps.plugins.general.nsclient.data;

/**
 * Created by mike on 11.06.2017.
 */

public class AlarmAck {
    public Integer level = null;
    public String group = null;
    public Long silenceTime = null;
}
