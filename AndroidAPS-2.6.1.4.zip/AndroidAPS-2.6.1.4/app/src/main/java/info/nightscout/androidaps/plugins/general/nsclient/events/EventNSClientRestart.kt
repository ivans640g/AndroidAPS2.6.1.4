package info.nightscout.androidaps.plugins.general.nsclient.events

import info.nightscout.androidaps.events.Event

class EventNSClientRestart : Event()
