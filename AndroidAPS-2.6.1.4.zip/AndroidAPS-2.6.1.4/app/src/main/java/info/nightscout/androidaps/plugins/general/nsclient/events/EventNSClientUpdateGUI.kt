package info.nightscout.androidaps.plugins.general.nsclient.events

import info.nightscout.androidaps.events.EventUpdateGui

class EventNSClientUpdateGUI : EventUpdateGui()
