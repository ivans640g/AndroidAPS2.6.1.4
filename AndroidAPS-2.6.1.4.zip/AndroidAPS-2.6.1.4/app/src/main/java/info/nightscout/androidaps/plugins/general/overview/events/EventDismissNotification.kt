package info.nightscout.androidaps.plugins.general.overview.events

import info.nightscout.androidaps.events.Event

class EventDismissNotification(var id: Int) : Event()
