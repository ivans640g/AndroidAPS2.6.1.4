package info.nightscout.androidaps.plugins.general.overview.events

import info.nightscout.androidaps.events.Event

class EventQuickWizardChange : Event()
