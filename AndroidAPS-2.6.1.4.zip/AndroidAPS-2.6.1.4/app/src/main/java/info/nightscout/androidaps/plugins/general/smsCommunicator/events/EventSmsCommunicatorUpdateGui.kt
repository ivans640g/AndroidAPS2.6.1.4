package info.nightscout.androidaps.plugins.general.smsCommunicator.events

import info.nightscout.androidaps.events.EventUpdateGui

class EventSmsCommunicatorUpdateGui : EventUpdateGui()
