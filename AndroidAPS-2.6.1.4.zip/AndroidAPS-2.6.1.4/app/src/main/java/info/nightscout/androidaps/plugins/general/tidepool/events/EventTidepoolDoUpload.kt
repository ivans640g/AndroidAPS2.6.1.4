package info.nightscout.androidaps.plugins.general.tidepool.events

import info.nightscout.androidaps.events.Event

class EventTidepoolDoUpload : Event()