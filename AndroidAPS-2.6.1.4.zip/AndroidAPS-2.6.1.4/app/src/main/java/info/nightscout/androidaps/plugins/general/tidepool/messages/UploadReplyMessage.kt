package info.nightscout.androidaps.plugins.general.tidepool.messages

class UploadReplyMessage {

    internal var data: List<String>? = null
}
