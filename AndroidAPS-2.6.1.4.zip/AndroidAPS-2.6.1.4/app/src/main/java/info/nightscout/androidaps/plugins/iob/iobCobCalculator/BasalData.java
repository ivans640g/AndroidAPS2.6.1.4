package info.nightscout.androidaps.plugins.iob.iobCobCalculator;

/**
 * Created by mike on 10.06.2017.
 */

public class BasalData {
    public double basal;
    public double tempBasalAbsolute;
    public boolean isTempBasalRunning;
}
