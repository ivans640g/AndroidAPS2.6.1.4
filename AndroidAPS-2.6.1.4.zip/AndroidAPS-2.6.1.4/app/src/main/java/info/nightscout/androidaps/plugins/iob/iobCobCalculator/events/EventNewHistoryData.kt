package info.nightscout.androidaps.plugins.iob.iobCobCalculator.events

import info.nightscout.androidaps.events.Event

class EventNewHistoryData(var time: Long) : Event()