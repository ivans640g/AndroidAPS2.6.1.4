package info.nightscout.androidaps.plugins.profile.local.events

import info.nightscout.androidaps.events.Event

class EventLocalProfileChanged : Event() {
}