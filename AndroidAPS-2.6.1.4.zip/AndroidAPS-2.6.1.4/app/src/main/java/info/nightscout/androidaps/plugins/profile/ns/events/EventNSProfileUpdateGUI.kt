package info.nightscout.androidaps.plugins.profile.ns.events

import info.nightscout.androidaps.events.EventUpdateGui

class EventNSProfileUpdateGUI : EventUpdateGui()
