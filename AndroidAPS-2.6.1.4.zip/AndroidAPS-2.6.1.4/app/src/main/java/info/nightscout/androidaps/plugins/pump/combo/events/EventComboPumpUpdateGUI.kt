package info.nightscout.androidaps.plugins.pump.combo.events

import info.nightscout.androidaps.events.EventUpdateGui

class EventComboPumpUpdateGUI : EventUpdateGui()