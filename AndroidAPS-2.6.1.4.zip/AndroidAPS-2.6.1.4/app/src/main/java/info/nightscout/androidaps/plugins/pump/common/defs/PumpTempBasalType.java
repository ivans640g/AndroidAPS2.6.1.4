package info.nightscout.androidaps.plugins.pump.common.defs;

/**
 * Created by andy on 02/05/2018.
 */

public enum PumpTempBasalType {
    Percent, //
    Absolute,
}
