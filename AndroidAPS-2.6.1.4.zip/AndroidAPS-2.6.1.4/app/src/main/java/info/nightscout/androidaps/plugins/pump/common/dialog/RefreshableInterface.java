package info.nightscout.androidaps.plugins.pump.common.dialog;

/**
 * Created by andy on 5/19/18.
 */

public interface RefreshableInterface {

    void refreshData();

}
