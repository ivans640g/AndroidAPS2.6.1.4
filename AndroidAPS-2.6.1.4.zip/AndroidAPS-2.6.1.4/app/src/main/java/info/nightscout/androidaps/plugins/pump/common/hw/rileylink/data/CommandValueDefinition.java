package info.nightscout.androidaps.plugins.pump.common.hw.rileylink.data;

import info.nightscout.androidaps.plugins.pump.common.hw.rileylink.defs.CommandValueDefinitionType;

/**
 * Created by andy on 4/5/19.
 */

public class CommandValueDefinition {

    public CommandValueDefinitionType definitionType;
    public String value;

}
