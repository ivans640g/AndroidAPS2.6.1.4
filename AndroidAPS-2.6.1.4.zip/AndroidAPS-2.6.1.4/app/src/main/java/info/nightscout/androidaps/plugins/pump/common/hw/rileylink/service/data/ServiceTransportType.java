package info.nightscout.androidaps.plugins.pump.common.hw.rileylink.service.data;

/**
 * Created by andy on 31/05/18.
 */

public enum ServiceTransportType {

    Undefined, //
    ServiceNotification, //

    ServiceCommand, //
    ServiceResult

}
